package dao;

import dto.Major;
import dto.Student;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface StudentsDao {
    public Map<Major, List<Student>> getAllStudent();

    public Set<Major> getAllMajors();

    public List<Student> getStudentsByMajor(Major studentMajor);

    public Major getMajorByName(String name);

    public void addNewStudent (Student s);

    public boolean graduateStudent(Student s);

    public List<Student> searchStudents(Map<String, String> params);

}