package dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import dto.Major;
import dto.Student;

public class StudentsData {

    private static Major ComputerScience = new Major("ComputerScience", 10, 30000.00);
    private static Major Engineering = new Major("Engineering", 8, 25000.00);
    private static Major CyberSecurity = new Major("CyberSecurity", 9, 35000.00);

    public static Map<Major, List<Student>> getProdData() {
        Map <Major, List<Student>> prodData = new HashMap<>();
        prodData.put(ComputerScience,  new ArrayList<Student>());
        prodData.put(Engineering, new ArrayList<Student>());
        prodData.put(CyberSecurity,  new ArrayList<Student>());
        prodData.get(ComputerScience).add(new Student("Alfred", 'M', 25, 288992,LocalDate.parse("2013-04-18"), ComputerScience));
        prodData.get(CyberSecurity).add(new Student("Efe", 'M', 27, 287883, LocalDate.parse("2015-08-12"), CyberSecurity));
        prodData.get(ComputerScience).add(new Student("Scott", 'M', 22, 283992,LocalDate.parse("2013-04-18"), ComputerScience));
        prodData.get(Engineering).add(new Student("Isa", 'M', 23, 284533, LocalDate.parse("2015-08-12"), Engineering));

        return prodData;
    }
}