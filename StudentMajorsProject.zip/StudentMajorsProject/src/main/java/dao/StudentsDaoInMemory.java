package dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import dto.Major;
import dto.Student;

public class StudentsDaoInMemory implements StudentsDao {

    private Map<Major, List<Student>> students;


    public StudentsDaoInMemory(Map<Major, List<Student>> students) {
        super();
        this.students = students;
    }

    @Override
    public Map<Major, List<Student>> getAllStudent() {
        return new HashMap<Major, List<Student>>(students);
    }

    @Override
    public Set<Major> getAllMajors() {
        {
            return students.keySet();
        }
    }

    @Override
    public List<Student> getStudentsByMajor(Major major) {
        return students.get(major);
    }

    @Override
    public Major getMajorByName(String name) {
        Set<Major> majors = students.keySet();
        Major studentMajor =  majors.stream()
                .filter(b -> b.getName().equals(name))
                .findFirst()
                .orElse(null);
        return studentMajor;
    }

    @Override
    public void addNewStudent(Student s) {
        if(students.keySet().contains(s.getStudentMajor())) {
            students.get(s.getStudentMajor()).add(s);
        }
        else {
            students.put(s.getStudentMajor(), new ArrayList<Student>());
            students.get(s.getStudentMajor()).add(s);
        }

    }

    @Override
    public boolean graduateStudent(Student s) {
        return students.get(s.getStudentMajor()).remove(s);
    }

    @Override
    public List<Student> searchStudents(Map<String, String> params) {
        return null;
    }
}