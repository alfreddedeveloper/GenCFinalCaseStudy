import controller.StudentsController;
import dao.StudentsDao;
import dao.StudentsDaoInMemory;
import dao.StudentsData;
import dto.Student;
import service.StudentsService;
import view.Runner;
import view.StudentView;

public class StudentGeneral {
    public static void main(String[] args) {
        StudentsDao dao = new StudentsDaoInMemory(StudentsData.getProdData());
        Runner view = new StudentView();
        StudentsService service = new StudentsService(dao);
        StudentsController c = new StudentsController(view, service);
    }
}