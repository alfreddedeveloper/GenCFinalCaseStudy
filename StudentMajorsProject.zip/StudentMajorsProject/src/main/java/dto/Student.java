package dto;

import java.time.LocalDate;

public class Student {
    private String name;
    private char sex;
    private int age;
    private int studentId;
    private LocalDate dob;
    private Major studentMajor;

    public Student() {
        super();
    }

    //todo: generate exception for sex param outside of 'M', 'm', 'F', 'f'
    //View should prevent this as well, but may make a good exception handling example
    public Student(String name, char sex, int age, int studentId, LocalDate dob, Major studentMajor) {
        super();
        this.name = name;
        this.sex = sex;
        this.age = age;
        this.studentId = studentId;
        this.dob = dob;
        this.studentMajor = studentMajor;
    }

    @Override
    public String toString() {
        return name;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public char getSex() {
        return sex;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public Major getStudentMajor() {
        return studentMajor;
    }

    public void setStudentMajor(Major studentMajor) {
        this.studentMajor = studentMajor;
    }
}
