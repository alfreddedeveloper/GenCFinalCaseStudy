package dto;

import java.time.LocalDate;

public class AddStudentDto {
    private String name;
    private char sex;
    private int age;
    private int studentId;
    private LocalDate dob;
    private String studentMajor;


    public AddStudentDto() {
        super();
    }


    public AddStudentDto(String name, char sex, int age, int studentId, LocalDate dob, String studentMajor) {
        super();
        this.name = name;
        this.sex = sex;
        this.age = age;
        this.studentId = studentId;
        this.dob = dob;
        this.studentMajor = studentMajor;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public char getSex() {
        return sex;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public String getStudentMajor() {
        return studentMajor;
    }

    public void setStudentMajor(String studentMajor) {
        this.studentMajor = studentMajor;
    }
}