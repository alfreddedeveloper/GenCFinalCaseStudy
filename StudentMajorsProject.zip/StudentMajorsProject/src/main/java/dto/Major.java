package dto;

public class Major {

    private String name;
    private int difficulty;
    private Double cost;

    public Major() {
        super();
    }

    public Major(String name, int difficulty, Double cost) {
        super();
        this.name = name;
        this.difficulty = difficulty;
        this.cost = cost;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }

}