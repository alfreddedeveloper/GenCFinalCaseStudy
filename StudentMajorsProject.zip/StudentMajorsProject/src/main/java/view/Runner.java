package view;

import controller.StudentsController;

public interface Runner {
    public void run(StudentsController c);
}