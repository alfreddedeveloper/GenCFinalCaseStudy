package view;

import java.time.LocalDate;
import java.util.List;

import controller.StudentsController;
import dto.AddStudentDto;
import dto.Student;
import service.InvalidMajorNameException;

public class StudentView implements Runner{
    StudentsController controller;

    @Override
    public void run(StudentsController c) {
        controller = c;
        // TODO Auto-generated method stub

        System.out.println("All Students: " +c.listStudents());
        System.out.println("All Majors: " +c.getMajors());
        System.out.println("All StudentID: " );
        System.out.println("Majors Available: " +c.getMajors());
        try {
            c.addStudent(new AddStudentDto("Arnold", 'M', 35, 288092, LocalDate.parse("2015-02-17"), "Computer Science"));
            System.out.println("Arnold added");
        }
        catch(InvalidMajorNameException e) {
            System.out.println(e.getMessage());
        }

        try {
            c.addStudent(new AddStudentDto("Psychology", 'M', 25 , 234788, LocalDate.parse("2014-08-11"), "Engineering"));
            System.out.println("Psychology added");
        }
        catch(InvalidMajorNameException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("All Computer Science students: " +c.listStudents("ComputerScience"));
        System.out.println("All Engineering students: " +c.listStudents("Engineering"));
        System.out.println("All CyberSecurity students: " +c.listStudents("CyberSecurity"));

        List<Student> available = c.listStudents();
        c.adoptStudent(available.get(1));
        System.out.println("Student Graduated");

        System.out.println("Major - Computer Science: " +c.listStudents());
        System.out.println("Major - Engineering: " +c.listStudents("Engineering"));
        System.out.println("Major - CyberSecurity: " +c.listStudents ("CyberSecurity"));
    }
}

