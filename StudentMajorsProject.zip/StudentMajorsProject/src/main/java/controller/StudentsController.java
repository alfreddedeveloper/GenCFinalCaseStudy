package controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import dto.*;
import service.StudentsService;
import view.Runner;

public class StudentsController {
    private Runner frontEnd;
    private StudentsService service;

    public StudentsController(Runner frontEnd, StudentsService service) {
        super();
        this.frontEnd = frontEnd;
        this.service = service;
        frontEnd.run(this);
    }

    public Student addStudent(AddStudentDto studData) {
        return service.addStudent(studData);
    }

    public List<Student> listStudents() {
        return service.findAllStudents();
    }

    public List<Student> listStudents(String student){
        return service.findStudentsByMajorName(student);
    }

    public void adoptStudent(Student student) { service.adoptGraduateStudent(student);
    }

    public List<String> getMajors() {
        List<Major> majors = service.getMajors();
        List<String> majorNames = new ArrayList<>();
        for (Major m : majors) {
            majorNames.add(m.getName());
        }
        Collections.sort(majorNames);
        return majorNames;
    }
}