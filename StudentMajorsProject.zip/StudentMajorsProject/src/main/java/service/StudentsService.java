package service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import dao.StudentsDao;
import dto.AddStudentDto;
import dto.Major;
import dto.Student;

public class StudentsService {

    StudentsDao dao;

    public StudentsService(StudentsDao dao) {
        this.dao = dao;
    }

    public Student addStudent(AddStudentDto studData) {
        Major major = dao.getMajorByName(studData.getName());

        if (major == null) throw new InvalidMajorNameException(studData.getName() + " is not a major recognized by this system.");

        Student student = new Student(studData.getName()
                , studData.getSex()
                , studData.getAge()
                , studData.getStudentId()
                , studData.getDob()
                , major);
        dao.addNewStudent(student);
        return student;
    }

    public List<Student> findStudentsByMajorName(String majorName) {
        Major major = dao.getMajorByName(majorName);

        if (major == null) throw new InvalidMajorNameException(majorName + " is not a major recognized by this system.");

        return dao.getStudentsByMajor(major);
    }

    public List<Student> findAllStudents() {
        Map<Major, List<Student>> studentMap = dao.getAllStudent();
        List<Student> students = new ArrayList<Student>();
        for(List<Student> p : studentMap.values()) {
            students.addAll(p);
        }
        return students;
    }

    public boolean adoptGraduateStudent(Student student) {
        return dao.graduateStudent(student);
    }

    public List<Major> getMajors() {
        return new ArrayList<Major>(dao.getAllMajors());
    }


}
