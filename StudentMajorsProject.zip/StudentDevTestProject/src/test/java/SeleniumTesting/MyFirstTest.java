package SeleniumTesting;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class MyFirstTest {

    @Test
    public static void main(String[] args) {

        System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        String baseUrl = "http://localhost:8080/TechnocratsUniversity/students/all";
        String expectedTitle = "Technocrats University";
        String actualTitle = "";


        driver.get(baseUrl);
        actualTitle = driver.getTitle();

        if (actualTitle.contentEquals(expectedTitle)) {
            System.out.println("Test Passed!");
        } else {
            System.out.println("Test Failed");
        }
    }

    @Test
    public void test2() {

        WebDriver driver = new ChromeDriver();
        driver.get("http://localhost:8080/TechnocratsUniversity/majors/all");


        driver.close();
        driver.quit();
    }

    @Test
    public void test3() {

        WebDriver driver = new ChromeDriver();
        driver.get("http://localhost:8080/TechnocratsUniversity/student/Addstudent");
        driver.close();
        driver.quit();
    }

}