package StudentDev.StudentDev4.resource;

import StudentDev.StudentDev4.model.student;
import StudentDev.StudentDev4.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/TechnocratsUniversity/students")
public class studentResource {

    @Autowired
    StudentRepository studentRepository;
    //view list of all Students
    @GetMapping(value= "/all")
    public List<student> getAll() {
        return studentRepository.findAll();
    }
    //add student
    @PostMapping(value = "/AddStudent")
    public List<student> persist (@RequestBody final student student){
        studentRepository.save(student);
        return studentRepository.findAll();
    }
}
