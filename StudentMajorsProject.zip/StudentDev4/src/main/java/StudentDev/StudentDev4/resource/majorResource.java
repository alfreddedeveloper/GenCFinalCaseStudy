package StudentDev.StudentDev4.resource;

import StudentDev.StudentDev4.model.major;
import StudentDev.StudentDev4.repository.MajorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/TechnocratsUniversity/majors")
public class majorResource {

    @Autowired
    MajorRepository majorRepository;
    //view list of all majors
    @GetMapping(value= "/all")
    public List<major> getAll() {
        return majorRepository.findAll();
    }
}
