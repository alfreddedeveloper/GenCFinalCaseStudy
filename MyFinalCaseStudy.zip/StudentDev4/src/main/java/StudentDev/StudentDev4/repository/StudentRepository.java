package StudentDev.StudentDev4.repository;

import StudentDev.StudentDev4.model.student;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories(basePackages = "com.StudentDev.db.repository")
@SpringBootApplication
public interface StudentRepository extends JpaRepository<student, Integer> {
}
