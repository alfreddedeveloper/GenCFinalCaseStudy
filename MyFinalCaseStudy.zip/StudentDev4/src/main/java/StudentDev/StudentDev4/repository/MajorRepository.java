package StudentDev.StudentDev4.repository;

import StudentDev.StudentDev4.model.major;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories(basePackages = "com.StudentDev.db.repository")
@SpringBootApplication
public interface MajorRepository extends JpaRepository<major, Integer> {
}
